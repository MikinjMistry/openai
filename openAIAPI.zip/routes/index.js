var express = require("express");
const { Configuration, OpenAIApi } = require("openai");
var router = express.Router();
// const openAI_key = "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";
// const openAI_key = "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";
const configuration = new Configuration({
  organization: "org-0rma4uB2ratvKgJZdg6nbeXq",
  apiKey: "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",
});

const openai = new OpenAIApi(configuration);

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express" });
});

router.post("/text-to-text", async function (req, res, next) {
  const { text, model } = req.body;
  try {
    const completion = await openai.createCompletion({
      model: model,
      prompt: text,
    });
    console.log("completion:", completion);
    res.json(completion.data);
  } catch (error) {
    console.log("error:", error);
    res.json(error);
  }
});

router.get("/text-to-image", async function (req, res, next) {
  
});

module.exports = router;
